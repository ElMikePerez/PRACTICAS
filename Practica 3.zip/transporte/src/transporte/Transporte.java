/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package transporte;

/**
 *
 * @author Aula 209
 */
public class Transporte {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Autobus dina = new Autobus();
        dina.Acelerar();
        Autobus inter = new Autobus(5);
        inter.Acelerar();
        Auto bocho = new Auto(15);
        System.out.println(bocho.Acelerar());
        System.out.println(bocho.SistemaConducir());
        System.out.println(bocho.ApagarMotor());
    }
    
}

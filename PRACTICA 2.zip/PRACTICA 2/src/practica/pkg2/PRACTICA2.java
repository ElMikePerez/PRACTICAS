/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.pkg2;

/**
 *
 * @author Aula 209
 */
public class PRACTICA2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Calculadora prueba= new Calculadora(10, 5);
        System.out.println(prueba.suma());
        System.out.println(prueba.resta());
        System.out.println(prueba.multiplicacion(3,4));
        System.out.println(prueba.division(8, 2));
    }
    
}

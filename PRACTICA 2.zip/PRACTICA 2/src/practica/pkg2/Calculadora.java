/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.pkg2;

/**
 *
 * @author Aula 209
 */
public class Calculadora implements ICalculadora{
    public int num1, num2, r;
    public double r2;
    public double division(double a, double b)
    {
        r2=a/b;
        return r2;
    }
    public int multiplicacion(int a, int b)
    {
       r=a*b;
       return r;
    }
    
    int suma()
    {
        r=num1+num2;
        return r;
    }
    int resta()
    {
        r=num1-num2;
        return r;
    }
    
    Calculadora(int a, int b)
    {
        num1=a;
        num2=b;
    }
}

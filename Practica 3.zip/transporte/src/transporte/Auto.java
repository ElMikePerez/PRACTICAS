/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package transporte;

/**
 *
 * @author FCFM
 */
public class Auto extends ATransporte implements ITransporte{
    
    private int velocidad;
    @Override
    public String Acelerar() {
        return "Auto acelerando";
    }

    @Override
    public String SistemaFrenos() {
        return "Auto frenando";
    }

    @Override
    public String SistemaConducir() {
        return "Conduciendo auto";
    }
    
    Auto(int vel)
    {
        this.velocidad=vel;
    }
}

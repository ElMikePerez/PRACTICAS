/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica1;

/**
 *
 * @author pc18
 */
public class Calculadora {
    private int c;
    public void Suma(int a, int b)
    {
        c=a+b;
        System.out.println(c);
    }
    
    public int resta(int a, int b)
    {
        c=a-b;
        return c;       
    }
}

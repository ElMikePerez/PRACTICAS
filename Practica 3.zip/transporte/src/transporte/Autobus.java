/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package transporte;

/**
 *
 * @author Aula 209
 */
public class Autobus extends ATransporte implements ITransporte{

    private int gasolina;
    
    public Autobus()
    {
        this.setGasolina(6);
        System.out.println(this.EncenderMotor(this.getGasolina()));
    }
    public Autobus(int gasolina)
    {
        this.gasolina = gasolina;
        System.out.println(this.EncenderMotor(gasolina));
    }
    
    private String EncenderMotor(int gasolina) {
        if(gasolina>1)
            return "Autobus Encendido";
        else
            return "Autobus No Encendido";
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String SistemaFrenos() {
        return "Autobus Frenando";
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String SistemaConducir() {
        return "Autobus Conduciendo";
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    @Override
    public String Acelerar()
    {
        return "Bus Acelerando";
    }

    /**
     * @return the gasolina
     */
    public int getGasolina() {
        return gasolina;
    }

    /**
     * @param gasolina the gasolina to set
     */
    public void setGasolina(int gasolina) {
        this.gasolina = gasolina;
    }
}
